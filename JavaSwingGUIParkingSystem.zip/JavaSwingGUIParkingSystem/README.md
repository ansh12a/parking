# JavaSwingGUIParkingSystem

Car Park System GUI developed using Java Swing

## How to run Application

Compile the Application class and run main function. Enter the number of staff and visitor parking slots
on the pop up window and the program will take you to the home screen where you have access to further
functionality for the car park system.

## OOP Design

<p align="center">
  <img src="https://github.com/haxamxam/JavaSwingGUIParkingSystem/blob/main/oop.png" width="550" title="OOP">
</p>

## User Interface


<p align="center">
  <img src="https://github.com/haxamxam/JavaSwingGUIParkingSystem/blob/main/GUIv.png" width="750" title="Vacant">
  <img src="https://github.com/haxamxam/JavaSwingGUIParkingSystem/blob/main/GUIo.png" width="750" title="Occupied">
</p>
